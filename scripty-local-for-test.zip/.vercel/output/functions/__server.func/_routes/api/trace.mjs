import { a as getRequestIP, o as readBody, r as defineEventHandler, s as setResponseStatus } from "../../_libs/h3+rou3+srvx.mjs";
//#region site/trace-core.js
function ipv4ToInt(ip) {
	const parts = String(ip).split(".");
	if (parts.length !== 4) return null;
	let n = 0;
	for (const part of parts) {
		if (!/^\d{1,3}$/.test(part)) return null;
		const value = Number(part);
		if (value > 255) return null;
		n = (n << 8 | value) >>> 0;
	}
	return n;
}
function intToIpv4(n) {
	return [
		n >>> 24 & 255,
		n >>> 16 & 255,
		n >>> 8 & 255,
		n & 255
	].join(".");
}
function isIPv4(value) {
	return ipv4ToInt(value) != null;
}
function expandIPv6(ip) {
	let text = String(ip).trim().toLowerCase().split("%")[0];
	if (!text) return null;
	const mapped = text.match(/^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/);
	if (mapped && isIPv4(mapped[1])) {
		const n = ipv4ToInt(mapped[1]);
		text = `::ffff:${(n >>> 16 & 65535).toString(16)}:${(n & 65535).toString(16)}`;
	}
	if (text.includes(".")) return null;
	const halves = text.split("::");
	if (halves.length > 2) return null;
	let groups;
	if (halves.length === 2) {
		const left = halves[0] ? halves[0].split(":") : [];
		const right = halves[1] ? halves[1].split(":") : [];
		if (left.length + right.length > 8) return null;
		groups = [
			...left,
			...Array(8 - left.length - right.length).fill("0"),
			...right
		];
	} else {
		groups = text.split(":");
		if (groups.length !== 8) return null;
	}
	if (groups.some((group) => !/^[0-9a-f]{1,4}$/.test(group))) return null;
	return groups.map((group) => group.padStart(4, "0"));
}
function isIPv6(value) {
	return expandIPv6(value) != null;
}
function inCidrV4(ip, cidr) {
	const [base, bitsText] = cidr.split("/");
	const bits = Number(bitsText);
	const ipN = ipv4ToInt(ip);
	const baseN = ipv4ToInt(base);
	if (ipN == null || baseN == null || bits < 0 || bits > 32) return false;
	if (bits === 0) return true;
	const mask = bits === 32 ? 4294967295 : -1 << 32 - bits >>> 0;
	return (ipN & mask) === (baseN & mask);
}
function v4Mapped(groups) {
	if (!groups || !groups.slice(0, 5).every((group) => group === "0000") || groups[5] !== "ffff") return null;
	return intToIpv4((parseInt(groups[6], 16) << 16 | parseInt(groups[7], 16)) >>> 0);
}
function describeIp(ip) {
	if (isIPv4(ip)) {
		const n = ipv4ToInt(ip);
		const rules = [
			[
				"255.255.255.255/32",
				"Limited broadcast",
				"Heard only on the local link."
			],
			[
				"0.0.0.0/8",
				"This network",
				"Not a public destination. 0.0.0.0 means this host, on the machine itself."
			],
			[
				"10.0.0.0/8",
				"Private",
				"RFC 1918. Used inside a network and not routed on the public Internet."
			],
			[
				"100.64.0.0/10",
				"Shared address space",
				"RFC 6598. Carrier-grade NAT, between a subscriber and the public Internet."
			],
			[
				"127.0.0.0/8",
				"Loopback",
				"Stays on this machine. The host is talking to itself."
			],
			[
				"169.254.0.0/16",
				"Link-local",
				"RFC 3927. Used when DHCP fails. 169.254.169.254 is the cloud metadata address."
			],
			[
				"172.16.0.0/12",
				"Private",
				"RFC 1918. A local network, not a public route."
			],
			[
				"192.0.0.0/24",
				"Protocol assignment",
				"Reserved for IETF protocol use, not ordinary hosting."
			],
			[
				"192.0.2.0/24",
				"Documentation",
				"TEST-NET-1, RFC 5737. For examples, not a live network."
			],
			[
				"192.168.0.0/16",
				"Private",
				"RFC 1918. A typical home or office LAN."
			],
			[
				"198.18.0.0/15",
				"Benchmarking",
				"RFC 2544. For device tests, not production traffic."
			],
			[
				"198.51.100.0/24",
				"Documentation",
				"TEST-NET-2, RFC 5737."
			],
			[
				"203.0.113.0/24",
				"Documentation",
				"TEST-NET-3, RFC 5737."
			],
			[
				"224.0.0.0/4",
				"Multicast",
				"One packet, many listeners. Not a single host to open in a browser."
			],
			[
				"240.0.0.0/4",
				"Reserved",
				"Held for future use, not public unicast."
			]
		];
		let special = null;
		for (const [cidr, title, detail] of rules) if (inCidrV4(ip, cidr)) {
			special = {
				title,
				detail
			};
			break;
		}
		const leadingZero = String(ip).split(".").some((part) => part.length > 1 && part.startsWith("0"));
		return {
			version: 4,
			title: special ? special.title : "Public unicast",
			detail: special ? special.detail : leadingZero ? "Leading zeros were read as decimal, not octal." : "An ordinary public IPv4 address.",
			send: !special,
			expanded: intToIpv4(n),
			hex: `0x${n.toString(16).padStart(8, "0")}`,
			int: n,
			mapped: null
		};
	}
	const groups = expandIPv6(ip);
	if (!groups) return null;
	const mapped = v4Mapped(groups);
	if (mapped) {
		const inner = describeIp(mapped);
		return {
			...inner,
			version: 6,
			title: `IPv4-mapped (${inner.title})`,
			detail: `This is ::ffff:${mapped}. ${inner.detail}`,
			send: inner.send,
			expanded: groups.join(":"),
			hex: null,
			mapped
		};
	}
	const allZero = groups.every((group) => group === "0000");
	const loopback = groups.slice(0, 7).every((group) => group === "0000") && groups[7] === "0001";
	const first = parseInt(groups[0], 16);
	let special = null;
	if (allZero) special = ["Unspecified", "The empty address. It means no address, not a destination."];
	else if (loopback) special = ["Loopback", "The IPv6 loopback. It never leaves this machine."];
	else if ((first & 65024) === 64512) special = ["Unique local", "fc00::/7. Private IPv6, the equivalent of RFC 1918."];
	else if ((first & 65472) === 65152) special = ["Link-local", "fe80::/10. Valid only on one link."];
	else if ((first & 65280) === 65280) special = ["Multicast", "ff00::/8. Not a single host."];
	else if (groups[0] === "2001" && groups[1] === "0db8") special = ["Documentation", "2001:db8::/32. For examples, not a live network."];
	else if (groups[0] === "0100" && groups.slice(1, 4).every((group) => group === "0000")) special = ["Discard", "0100::/64. Traffic here is thrown away."];
	else if (groups[0] === "0064" && groups[1] === "ff9b" && groups.slice(2, 6).every((group) => group === "0000")) special = ["NAT64", "64:ff9b::/96. A well-known prefix that translates IPv4 into IPv6."];
	const note6to4 = groups[0] === "2002" ? " 2002::/16 is 6to4: the next 32 bits are an embedded IPv4 address." : "";
	return {
		version: 6,
		title: special ? special[0] : "Public unicast",
		detail: (special ? special[1] : "An ordinary public IPv6 address.") + note6to4,
		send: !special,
		expanded: groups.join(":"),
		hex: null,
		int: null,
		mapped: null
	};
}
//#endregion
//#region server/trace-proxy.mjs
var DOH = "https://cloudflare-dns.com/dns-query";
var RIPE = "https://stat.ripe.net/data";
var REDIRECT = "https://www.redirectcheck.org/api/check";
var SOURCE_APP = "whispr-trace";
var DNS_TYPES = /* @__PURE__ */ new Set([
	"A",
	"AAAA",
	"CNAME",
	"NS",
	"MX",
	"TXT",
	"SOA",
	"CAA",
	"HTTPS",
	"PTR",
	"SVCB"
]);
var RIPE_ENDPOINTS = /* @__PURE__ */ new Set([
	"prefix-overview",
	"routing-status",
	"rir",
	"abuse-contact-finder",
	"whois",
	"geoloc",
	"as-overview",
	"asn-neighbours",
	"announced-prefixes",
	"dns-chain"
]);
var hits = /* @__PURE__ */ new Map();
function tooMany(ip) {
	const key = ip || "unknown";
	const now = Date.now();
	const recent = (hits.get(key) || []).filter((t) => now - t < 6e4);
	if (recent.length >= 90) {
		hits.set(key, recent);
		return true;
	}
	recent.push(now);
	hits.set(key, recent);
	return false;
}
function publicUrl(value) {
	let url;
	try {
		url = new URL(String(value));
	} catch {
		return null;
	}
	if (url.protocol !== "http:" && url.protocol !== "https:") return null;
	if (url.username || url.password) return null;
	const host = url.hostname.replace(/\.$/, "").toLowerCase();
	if (!host || !host.includes(".") || host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal") || host.endsWith(".home.arpa")) return null;
	if (isIPv4(host) || isIPv6(host)) {
		if (!describeIp(host)?.send) return null;
	}
	url.hash = "";
	url.username = "";
	url.password = "";
	return url.href;
}
async function upstream(url, init) {
	const res = await fetch(url, {
		...init,
		signal: AbortSignal.timeout(2e4),
		redirect: "follow"
	});
	const text = await res.text();
	if (text.length > 15e5) return {
		status: 502,
		body: { error: "The reply was too large." }
	};
	try {
		return {
			status: res.ok ? 200 : res.status,
			body: JSON.parse(text)
		};
	} catch {
		return {
			status: 502,
			body: { error: "The lookup did not return data." }
		};
	}
}
async function runTrace(body) {
	if (!body || typeof body !== "object") return {
		status: 400,
		body: { error: "Bad request." }
	};
	if (body.op === "doh") {
		const name = String(body.name || "").trim().replace(/\.$/, "");
		const type = String(body.type || "").toUpperCase();
		if (!name || name.length > 253 || /[\s/\\]/.test(name) || !DNS_TYPES.has(type)) return {
			status: 400,
			body: { error: "That is not a DNS query this page will send." }
		};
		return upstream(`${DOH}?name=${encodeURIComponent(name)}&type=${encodeURIComponent(type)}`, { headers: { accept: "application/dns-json" } });
	}
	if (body.op === "ripe") {
		const endpoint = String(body.endpoint || "");
		const resource = String(body.resource || "").trim();
		if (!RIPE_ENDPOINTS.has(endpoint) || !resource || resource.length > 300 || /[\s\\]/.test(resource) || resource.includes("://")) return {
			status: 400,
			body: { error: "That is not a routing query this page will send." }
		};
		return upstream(`${RIPE}/${endpoint}/data.json?resource=${encodeURIComponent(resource)}&sourceapp=${SOURCE_APP}`, { headers: { accept: "application/json" } });
	}
	if (body.op === "redirect") {
		const href = publicUrl(body.url);
		if (!href) return {
			status: 400,
			body: { error: "Only public http and https addresses are followed." }
		};
		return upstream(REDIRECT, {
			method: "POST",
			headers: {
				"content-type": "application/json",
				accept: "application/json"
			},
			body: JSON.stringify({
				url: href,
				method: "GET",
				followMetaRefresh: true,
				maxHops: 15
			})
		});
	}
	return {
		status: 400,
		body: { error: "Unknown lookup." }
	};
}
//#endregion
//#region server/api/trace.post.mjs
var trace_post_default = defineEventHandler(async (event) => {
	if (tooMany(getRequestIP(event, { xForwardedFor: true }))) {
		setResponseStatus(event, 429);
		return { error: "Too many lookups. Wait a minute." };
	}
	let body;
	try {
		body = await readBody(event);
	} catch {
		setResponseStatus(event, 400);
		return { error: "Bad request." };
	}
	const result = await runTrace(body);
	setResponseStatus(event, result.status);
	return result.body;
});
//#endregion
export { trace_post_default as default };
