import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { mount } from "../../site/app.js";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    return mount(el);
  }, []);
  return (
    <>
      <noscript>This page needs JavaScript to trace a link.</noscript>
      <div ref={ref} className="trace-mount" />
    </>
  );
}
