// @ts-nocheck
import { defineEventHandler, getRequestIP, readBody, setResponseStatus } from "h3";
import { runTrace, tooMany } from "../trace-proxy.mjs";

export default defineEventHandler(async (event) => {
  if (tooMany(getRequestIP(event, { xForwardedFor: true }))) {
    setResponseStatus(event, 429);
    return { error: "Too many lookups. Wait a minute." };
  }
  let body;
  try {
    body = await readBody(event);
  } catch {
    setResponseStatus(event, 400);
    return { error: "Bad request." };
  }
  const result = await runTrace(body);
  setResponseStatus(event, result.status);
  return result.body;
});
