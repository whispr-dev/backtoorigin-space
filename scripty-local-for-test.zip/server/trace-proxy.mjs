// @ts-nocheck
import { describeIp, isIPv4, isIPv6 } from "../site/trace-core.js";

const DOH = "https://cloudflare-dns.com/dns-query";
const RIPE = "https://stat.ripe.net/data";
const REDIRECT = "https://www.redirectcheck.org/api/check";
const SOURCE_APP = "whispr-trace";

const DNS_TYPES = new Set(["A", "AAAA", "CNAME", "NS", "MX", "TXT", "SOA", "CAA", "HTTPS", "PTR", "SVCB"]);
const RIPE_ENDPOINTS = new Set([
  "prefix-overview",
  "routing-status",
  "rir",
  "abuse-contact-finder",
  "whois",
  "geoloc",
  "as-overview",
  "asn-neighbours",
  "announced-prefixes",
  "dns-chain",
]);

const hits = new Map();

export function tooMany(ip) {
  const key = ip || "unknown";
  const now = Date.now();
  const recent = (hits.get(key) || []).filter((t) => now - t < 60_000);
  if (recent.length >= 90) {
    hits.set(key, recent);
    return true;
  }
  recent.push(now);
  hits.set(key, recent);
  return false;
}

function publicUrl(value) {
  let url;
  try {
    url = new URL(String(value));
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  if (url.username || url.password) return null;
  const host = url.hostname.replace(/\.$/, "").toLowerCase();
  if (!host || !host.includes(".") || host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal") || host.endsWith(".home.arpa")) {
    return null;
  }
  if (isIPv4(host) || isIPv6(host)) {
    const info = describeIp(host);
    if (!info?.send) return null;
  }
  url.hash = "";
  url.username = "";
  url.password = "";
  return url.href;
}

async function upstream(url, init) {
  const res = await fetch(url, { ...init, signal: AbortSignal.timeout(20000), redirect: "follow" });
  const text = await res.text();
  if (text.length > 1_500_000) return { status: 502, body: { error: "The reply was too large." } };
  try {
    return { status: res.ok ? 200 : res.status, body: JSON.parse(text) };
  } catch {
    return { status: 502, body: { error: "The lookup did not return data." } };
  }
}

export async function runTrace(body) {
  if (!body || typeof body !== "object") return { status: 400, body: { error: "Bad request." } };
  if (body.op === "doh") {
    const name = String(body.name || "").trim().replace(/\.$/, "");
    const type = String(body.type || "").toUpperCase();
    if (!name || name.length > 253 || /[\s/\\]/.test(name) || !DNS_TYPES.has(type)) {
      return { status: 400, body: { error: "That is not a DNS query this page will send." } };
    }
    return upstream(`${DOH}?name=${encodeURIComponent(name)}&type=${encodeURIComponent(type)}`, {
      headers: { accept: "application/dns-json" },
    });
  }
  if (body.op === "ripe") {
    const endpoint = String(body.endpoint || "");
    const resource = String(body.resource || "").trim();
    if (!RIPE_ENDPOINTS.has(endpoint) || !resource || resource.length > 300 || /[\s\\]/.test(resource) || resource.includes("://")) {
      return { status: 400, body: { error: "That is not a routing query this page will send." } };
    }
    return upstream(`${RIPE}/${endpoint}/data.json?resource=${encodeURIComponent(resource)}&sourceapp=${SOURCE_APP}`, {
      headers: { accept: "application/json" },
    });
  }
  if (body.op === "redirect") {
    const href = publicUrl(body.url);
    if (!href) return { status: 400, body: { error: "Only public http and https addresses are followed." } };
    return upstream(REDIRECT, {
      method: "POST",
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({ url: href, method: "GET", followMetaRefresh: true, maxHops: 15 }),
    });
  }
  return { status: 400, body: { error: "Unknown lookup." } };
}
