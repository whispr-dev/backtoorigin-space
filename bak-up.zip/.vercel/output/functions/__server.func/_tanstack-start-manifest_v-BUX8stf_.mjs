//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BUX8stf_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-hX5Th3Zw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-hX5Th3Zw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BmzbG_7g.js"]
	}
} });
//#endregion
export { tsrStartManifest };
